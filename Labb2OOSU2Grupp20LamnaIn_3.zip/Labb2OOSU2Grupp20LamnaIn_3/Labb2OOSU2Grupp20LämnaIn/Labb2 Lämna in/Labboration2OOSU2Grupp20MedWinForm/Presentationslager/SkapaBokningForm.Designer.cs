﻿namespace Presentationslager
{
    partial class SkapaBokningForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            VljBöcker_listBox = new System.Windows.Forms.ListBox();
            Meny_button = new System.Windows.Forms.Button();
            VljBöcker_label = new System.Windows.Forms.Label();
            Lånstart_label = new System.Windows.Forms.Label();
            LånSlut_label = new System.Windows.Forms.Label();
            HittaMedlem_textBox = new System.Windows.Forms.TextBox();
            HittaMedlem_label = new System.Windows.Forms.Label();
            HämtaTillgängligaBcker_button = new System.Windows.Forms.Button();
            Lånstart_Picker = new System.Windows.Forms.DateTimePicker();
            LånSlut_Picker = new System.Windows.Forms.DateTimePicker();
            SkapaBokning_button = new System.Windows.Forms.Button();
            ValdaBöcker_listBox = new System.Windows.Forms.ListBox();
            SuspendLayout();
            // 
            // VljBöcker_listBox
            // 
            VljBöcker_listBox.FormattingEnabled = true;
            VljBöcker_listBox.ItemHeight = 15;
            VljBöcker_listBox.Location = new System.Drawing.Point(349, 39);
            VljBöcker_listBox.Name = "VljBöcker_listBox";
            VljBöcker_listBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            VljBöcker_listBox.Size = new System.Drawing.Size(308, 124);
            VljBöcker_listBox.TabIndex = 1;
            VljBöcker_listBox.Visible = false;
            VljBöcker_listBox.MouseClick += VljBöcker_listBox_MouseClick;
            // 
            // Meny_button
            // 
            Meny_button.Location = new System.Drawing.Point(15, 249);
            Meny_button.Name = "Meny_button";
            Meny_button.Size = new System.Drawing.Size(75, 23);
            Meny_button.TabIndex = 2;
            Meny_button.Text = "Meny";
            Meny_button.UseVisualStyleBackColor = true;
            Meny_button.Click += Meny_button_Click;
            // 
            // VljBöcker_label
            // 
            VljBöcker_label.AutoSize = true;
            VljBöcker_label.Location = new System.Drawing.Point(349, 21);
            VljBöcker_label.Name = "VljBöcker_label";
            VljBöcker_label.Size = new System.Drawing.Size(181, 15);
            VljBöcker_label.TabIndex = 4;
            VljBöcker_label.Text = "Markera böckerna som ska lånas!";
            VljBöcker_label.Visible = false;
            // 
            // Lånstart_label
            // 
            Lånstart_label.AutoSize = true;
            Lånstart_label.Location = new System.Drawing.Point(23, 83);
            Lånstart_label.Name = "Lånstart_label";
            Lånstart_label.Size = new System.Drawing.Size(110, 15);
            Lånstart_label.TabIndex = 7;
            Lånstart_label.Text = "När ska lånet börja?";
            // 
            // LånSlut_label
            // 
            LånSlut_label.AutoSize = true;
            LånSlut_label.Location = new System.Drawing.Point(23, 161);
            LånSlut_label.Name = "LånSlut_label";
            LånSlut_label.Size = new System.Drawing.Size(108, 15);
            LånSlut_label.TabIndex = 8;
            LånSlut_label.Text = "När ska lånet sluta?";
            // 
            // HittaMedlem_textBox
            // 
            HittaMedlem_textBox.Location = new System.Drawing.Point(23, 39);
            HittaMedlem_textBox.Name = "HittaMedlem_textBox";
            HittaMedlem_textBox.Size = new System.Drawing.Size(125, 23);
            HittaMedlem_textBox.TabIndex = 9;
            // 
            // HittaMedlem_label
            // 
            HittaMedlem_label.AutoSize = true;
            HittaMedlem_label.Location = new System.Drawing.Point(23, 21);
            HittaMedlem_label.Name = "HittaMedlem_label";
            HittaMedlem_label.Size = new System.Drawing.Size(204, 15);
            HittaMedlem_label.TabIndex = 10;
            HittaMedlem_label.Text = "Vilken medlem ska låna? (MedlemNr)";
            // 
            // HämtaTillgängligaBcker_button
            // 
            HämtaTillgängligaBcker_button.Location = new System.Drawing.Point(235, 39);
            HämtaTillgängligaBcker_button.Name = "HämtaTillgängligaBcker_button";
            HämtaTillgängligaBcker_button.Size = new System.Drawing.Size(99, 42);
            HämtaTillgängligaBcker_button.TabIndex = 11;
            HämtaTillgängligaBcker_button.Text = "Visa tillgängliga böcker";
            HämtaTillgängligaBcker_button.UseVisualStyleBackColor = true;
            HämtaTillgängligaBcker_button.Click += HämtaTillgängligaBcker_button_Click;
            // 
            // Lånstart_Picker
            // 
            Lånstart_Picker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            Lånstart_Picker.Location = new System.Drawing.Point(23, 101);
            Lånstart_Picker.Name = "Lånstart_Picker";
            Lånstart_Picker.Size = new System.Drawing.Size(200, 23);
            Lånstart_Picker.TabIndex = 12;
            Lånstart_Picker.Value = new System.DateTime(2024, 4, 16, 19, 33, 41, 0);
            // 
            // LånSlut_Picker
            // 
            LånSlut_Picker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            LånSlut_Picker.Location = new System.Drawing.Point(23, 179);
            LånSlut_Picker.Name = "LånSlut_Picker";
            LånSlut_Picker.Size = new System.Drawing.Size(200, 23);
            LånSlut_Picker.TabIndex = 13;
            LånSlut_Picker.Value = new System.DateTime(2024, 4, 16, 19, 33, 51, 0);
            // 
            // SkapaBokning_button
            // 
            SkapaBokning_button.Location = new System.Drawing.Point(663, 33);
            SkapaBokning_button.Name = "SkapaBokning_button";
            SkapaBokning_button.Size = new System.Drawing.Size(125, 54);
            SkapaBokning_button.TabIndex = 14;
            SkapaBokning_button.Text = "Skapa bokning";
            SkapaBokning_button.UseVisualStyleBackColor = true;
            SkapaBokning_button.Visible = false;
            SkapaBokning_button.Click += SkapaBokning_button_Click;
            // 
            // ValdaBöcker_listBox
            // 
            ValdaBöcker_listBox.FormattingEnabled = true;
            ValdaBöcker_listBox.ItemHeight = 15;
            ValdaBöcker_listBox.Location = new System.Drawing.Point(349, 179);
            ValdaBöcker_listBox.Name = "ValdaBöcker_listBox";
            ValdaBöcker_listBox.Size = new System.Drawing.Size(190, 94);
            ValdaBöcker_listBox.TabIndex = 15;
            ValdaBöcker_listBox.Visible = false;
            // 
            // SkapaBokningForm
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 295);
            Controls.Add(ValdaBöcker_listBox);
            Controls.Add(SkapaBokning_button);
            Controls.Add(LånSlut_Picker);
            Controls.Add(Lånstart_Picker);
            Controls.Add(HämtaTillgängligaBcker_button);
            Controls.Add(HittaMedlem_label);
            Controls.Add(HittaMedlem_textBox);
            Controls.Add(LånSlut_label);
            Controls.Add(Lånstart_label);
            Controls.Add(VljBöcker_label);
            Controls.Add(Meny_button);
            Controls.Add(VljBöcker_listBox);
            Name = "SkapaBokningForm";
            Text = "Bibliotek - Bokning";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.ListBox VljBöcker_listBox;
        private System.Windows.Forms.Button Meny_button;
        private System.Windows.Forms.Label VljBöcker_label;
        private System.Windows.Forms.Label Lånstart_label;
        private System.Windows.Forms.Label LånSlut_label;
        private System.Windows.Forms.TextBox HittaMedlem_textBox;
        private System.Windows.Forms.Label HittaMedlem_label;
        private System.Windows.Forms.Button HämtaTillgängligaBcker_button;
        private System.Windows.Forms.DateTimePicker LånStart_Box;
        private System.Windows.Forms.DateTimePicker LånSlut_Box;
        private System.Windows.Forms.DateTimePicker Lånstart_Picker;
        private System.Windows.Forms.DateTimePicker LånSlut_Picker;
        private System.Windows.Forms.Button SkapaBokning_button;
        private System.Windows.Forms.ListBox ValdaBöcker_listBox;
    }
}