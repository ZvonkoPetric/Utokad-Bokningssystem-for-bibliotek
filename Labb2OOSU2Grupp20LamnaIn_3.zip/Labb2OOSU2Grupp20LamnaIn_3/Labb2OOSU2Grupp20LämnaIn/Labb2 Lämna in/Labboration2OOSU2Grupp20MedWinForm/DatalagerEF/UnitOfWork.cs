﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entitestlager;
namespace DatalagerEF
{
    public class UnitOfWork
    {
        private BibliotekContext context { get; }
        public Repository<Anställd> AnställdRepository
        {
            get; private set;
        }

        public Repository<Medlem> MedlemRepository
        {
            get; private set;
        }

        public Repository<Bok> BokRepository
        {
            get; private set;
        }

        public Repository<Faktura> FakturaRepository
        {
            get; private set;
        }

        public Repository<Bokning> BokningRepository
        {
            get; private set;
        }
        /// <summary>
        ///  Create a new instance.
        /// </summary>
        public UnitOfWork()
        {
            context = new BibliotekContext();
                
            AnställdRepository = new Repository<Anställd>(context);
            BokRepository = new Repository<Bok>(context);
            BokningRepository = new Repository<Bokning>(context);
            FakturaRepository = new Repository<Faktura>(context);
            MedlemRepository = new Repository<Medlem>(context);
        }

        /// <summary>
        ///  Save the changes made. Does nothing in this case.
        /// </summary>
        public void Save()
        {
            context.SaveChanges();
        }
    }
}
