﻿using Affärslager;
using Entitestlager;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Presentationslager
{
    public partial class SkapaBokningForm : Form
    {
        private Bibliotek bibliotek;
        IEnumerable<Bok> tillgängligaBöcker;
        public List<Bok> LäggBöcker { get; set; }
        public List<Bok> ValdaBöcker;
        public SkapaBokningForm(Bibliotek bibliotek)
        {
            InitializeComponent();
            this.CenterToScreen();
            this.bibliotek = bibliotek;
        }

        private void Meny_button_Click(object sender, EventArgs e)
        {
            this.Close();
            new MenyForm(bibliotek).Show();
        }

        private void HämtaTillgängligaBcker_button_Click(object sender, EventArgs e)
        {
            //Sätter dessa till rätt värden ifall man gör ändringar. 
            HittaMedlem_label.ForeColor = Color.Black;
            HittaMedlem_label.Text = "Vilken medlem ska låna? (MedlemNr)";
            LånSlut_label.ForeColor = Color.Black;
            LånSlut_label.Text = "När ska lånet sluta?";
            SkapaBokning_button.Visible = false;
            //----------------------------------------------------------------

            if (bibliotek.KontrolleraMedlemsNummer(HittaMedlem_textBox.Text) != false && Lånstart_Picker.Value <= LånSlut_Picker.Value)
            {

                VljBöcker_label.Visible = true;
                VljBöcker_listBox.Visible = true;
                foreach (Bok bok in bibliotek.HämtaTillgängligaBöcker(Lånstart_Picker.Value, LånSlut_Picker.Value, bibliotek.valdMedlem))
                {
                    VljBöcker_listBox.Items.Add(bok);
                }

            }
            else if (bibliotek.KontrolleraMedlemsNummer(HittaMedlem_textBox.Text) == false)
            {
                HittaMedlem_label.ForeColor = Color.Red;
                HittaMedlem_label.Text = "Medlem kunde inte hittas, försök igen!";

            }
            else if (Lånstart_Picker.Value > LånSlut_Picker.Value)
            {
                LånSlut_label.ForeColor = Color.Red;
                LånSlut_label.Text = "Vald datum måste vara senare än start datum!";
            }
        }

        private void VljBöcker_listBox_MouseClick(object sender, MouseEventArgs e)
        {
            ValdaBöcker_listBox.Items.Add(VljBöcker_listBox.SelectedItem);
            VljBöcker_listBox.Items.Remove(VljBöcker_listBox.SelectedItem);
            SkapaBokning_button.Visible = true;
            ValdaBöcker = new List<Bok>();

            if (ValdaBöcker_listBox.Items.Count != 0)
            {
                foreach (Bok bok in ValdaBöcker_listBox.Items)
                {
                    ValdaBöcker.Add(bok);
                }
            }
        }

        private void SkapaBokning_button_Click(object sender, EventArgs e)
        {

            if (ValdaBöcker != null)
            {
                Bokning skapadBokning = bibliotek.SparaBokning(Lånstart_Picker.Value, LånSlut_Picker.Value, ValdaBöcker, bibliotek.valdMedlem);
                MessageBox.Show("Bokningen är nu skapad, Bokningsnummret = " + skapadBokning.Bokningsnummer);
                this.Close();
                new MenyForm(bibliotek).Show();
            }
            else { MessageBox.Show("Du måste välja böcker!"); }
        }
    }
}
