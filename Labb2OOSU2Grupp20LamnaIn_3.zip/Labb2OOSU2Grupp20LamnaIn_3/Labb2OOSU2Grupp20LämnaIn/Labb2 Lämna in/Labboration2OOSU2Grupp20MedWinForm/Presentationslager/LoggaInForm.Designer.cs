﻿namespace Presentationslager
{
    partial class LoggaInForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LoggaIn_button = new System.Windows.Forms.Button();
            Användare_textBox = new System.Windows.Forms.TextBox();
            Lösenord_textBox = new System.Windows.Forms.TextBox();
            Användare_label = new System.Windows.Forms.Label();
            Lösen_label = new System.Windows.Forms.Label();
            FailLogin_label = new System.Windows.Forms.Label();
            SuspendLayout();
            // 
            // LoggaIn_button
            // 
            LoggaIn_button.Location = new System.Drawing.Point(148, 114);
            LoggaIn_button.Name = "LoggaIn_button";
            LoggaIn_button.Size = new System.Drawing.Size(113, 31);
            LoggaIn_button.TabIndex = 0;
            LoggaIn_button.Text = "Logga in";
            LoggaIn_button.UseVisualStyleBackColor = true;
            LoggaIn_button.Click += LoggaIn_button_Click;
            // 
            // Användare_textBox
            // 
            Användare_textBox.Location = new System.Drawing.Point(87, 29);
            Användare_textBox.Name = "Användare_textBox";
            Användare_textBox.Size = new System.Drawing.Size(100, 23);
            Användare_textBox.TabIndex = 1;
            // 
            // Lösenord_textBox
            // 
            Lösenord_textBox.Location = new System.Drawing.Point(87, 63);
            Lösenord_textBox.Name = "Lösenord_textBox";
            Lösenord_textBox.Size = new System.Drawing.Size(100, 23);
            Lösenord_textBox.TabIndex = 2;
            // 
            // Användare_label
            // 
            Användare_label.AutoSize = true;
            Användare_label.Location = new System.Drawing.Point(6, 32);
            Användare_label.Name = "Användare_label";
            Användare_label.Size = new System.Drawing.Size(75, 15);
            Användare_label.TabIndex = 3;
            Användare_label.Text = "Användar ID:";
            // 
            // Lösen_label
            // 
            Lösen_label.AutoSize = true;
            Lösen_label.Location = new System.Drawing.Point(22, 66);
            Lösen_label.Name = "Lösen_label";
            Lösen_label.Size = new System.Drawing.Size(59, 15);
            Lösen_label.TabIndex = 4;
            Lösen_label.Text = "Lösenord:";
            // 
            // FailLogin_label
            // 
            FailLogin_label.AutoSize = true;
            FailLogin_label.ForeColor = System.Drawing.Color.Red;
            FailLogin_label.Location = new System.Drawing.Point(33, 96);
            FailLogin_label.Name = "FailLogin_label";
            FailLogin_label.Size = new System.Drawing.Size(0, 15);
            FailLogin_label.TabIndex = 5;
            // 
            // LoggaInForm
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(273, 157);
            Controls.Add(FailLogin_label);
            Controls.Add(Lösen_label);
            Controls.Add(Användare_label);
            Controls.Add(Lösenord_textBox);
            Controls.Add(Användare_textBox);
            Controls.Add(LoggaIn_button);
            Name = "LoggaInForm";
            Text = "Bibliotek - Logga in";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button LoggaIn_button;
        private System.Windows.Forms.TextBox Användare_textBox;
        private System.Windows.Forms.TextBox Lösenord_textBox;
        private System.Windows.Forms.Label Användare_label;
        private System.Windows.Forms.Label Lösen_label;
        private System.Windows.Forms.Label FailLogin_label;
    }
}
