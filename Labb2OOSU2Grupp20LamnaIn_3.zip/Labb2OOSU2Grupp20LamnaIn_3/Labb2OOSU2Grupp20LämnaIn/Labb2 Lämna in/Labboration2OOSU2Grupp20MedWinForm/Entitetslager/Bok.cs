﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Entitestlager
{
    public class Bok
    {
        private Bok() { }

        [Key]
        public int BokID { get; set; }


        public int ISBN { get; set; }
        public string Titel { get; set; }
        public bool Tillgänglighet { get; set; }

        public Bok(int ISBN, string Titel, bool tillgänglighet)
        {
            this.ISBN = ISBN;
            this.Titel = Titel;
            Tillgänglighet = tillgänglighet;
        }
        //För WinForm. 
        public override string ToString()
        {
            return $"Titel: {Titel}   -    ISBN: {ISBN}";
        }
    }
}
