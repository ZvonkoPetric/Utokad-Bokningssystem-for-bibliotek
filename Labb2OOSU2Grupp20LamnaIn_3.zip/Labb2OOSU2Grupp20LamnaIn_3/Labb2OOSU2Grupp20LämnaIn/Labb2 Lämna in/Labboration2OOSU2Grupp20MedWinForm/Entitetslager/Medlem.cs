﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Entitestlager
{
    public class Medlem
    {
        private Medlem() { }

        [Key]
        public int MedlemID { get; set; }


        public int Medlemmsnummer { get; private set; }
        public string Namn { get; private set; }
        public int Telefonnummer { get; private set; }
        public string Epostadress { get; private set; }

        public List<Bokning> Bokningar { get; set; }

        public Medlem(int Medlemmsnummer, string Namn, int Telefonnummer, string Epostadress)
        {
            Bokningar = new List<Bokning>();
            this.Medlemmsnummer = Medlemmsnummer;
            this.Namn = Namn;
            this.Telefonnummer = Telefonnummer;
            this.Epostadress = Epostadress;
        }
    }
}
